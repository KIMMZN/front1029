package www.silver.dao;

import java.util.List;

import www.silver.vo.boardVO;

public interface IF_boardao {
	
	public void wirteOne(boardVO boardvo)throws Exception;
	//게시판글보기요청
	public List<boardVO> listall() throws Exception;
	
	//delone
	public void deleteOne(int delno)throws Exception;
	
	//select update view
	public boardVO selectOne(int delno)throws Exception;
	
	//글 수정 요청
	public void updateOne(boardVO boardvo)throws Exception;
	

}
