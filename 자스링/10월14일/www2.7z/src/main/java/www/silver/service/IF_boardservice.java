package www.silver.service;

import java.util.List;

import www.silver.vo.boardVO;

public interface IF_boardservice {
	
	public void writeOne(boardVO boardvo) throws Exception;
	public List<boardVO> listall() throws Exception;
	
	//클라이언트: 선택한 글 한개를 삭제요청(pk num param으로 넘김)
	public void delOne(int delno) throws Exception;
	//수정을 위한, pk num을 넘기고 한개의 튜플(객체활용) 불러오기
	public boardVO modOne(int delno)throws Exception;
	//수정요청
	public void modOne(boardVO boardvo)throws Exception;

}
