package www.silver.hom;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import www.silver.service.IF_boardservice;
import www.silver.vo.boardVO;

@Controller
public class BoardController {

	@Inject
	IF_boardservice ifboards;
	
	@GetMapping(value="complaint")
	public String announce(Model model) throws Exception {
		//여기가 게시판 뷰
		//클라이언트가 게시판보기를 요청
		//ifboards.listall();
		
		//model.addAttribute = ifboards.listall();
		
		List<boardVO> list = ifboards.listall();
		
		System.out.println(list.size() +"건 가져옴");
		
		model.addAttribute("list",list);
		
				
		return "/board/complaint";
	}
	
	@GetMapping(value="bwr")
	public String bwr() {
		
		
		
		
		return "/board/complaintWr";
	}
	
	@PostMapping(value="bwrite")
	public String bwrite(@ModelAttribute boardVO boardvo) throws Exception {
		
		
		ifboards.writeOne(boardvo);
		System.out.println(boardvo.toString());
		
		return "redirect:complaint";
	}
	
	@GetMapping(value = "delone")
	public String delone(@RequestParam int delno) throws Exception {
		
		
		ifboards.delOne(delno);
		//
		//System.out.println(delno+"  넘긴 글번호");
		
		return "redirect:complaint";
	}
	
	@GetMapping(value = "update")
	public String update(@RequestParam int delno, Model model) throws Exception {
		//pk num을 param으로 넘기고
		//모델 객체 활용  뷰로 리턴
		
		boardVO baordvo = ifboards.modOne(delno);
		
		model.addAttribute(baordvo);
		
		
		System.out.println(delno+"  넘긴 글번호");
		
		return "board/complaintUpdate";
	}
	
	@PostMapping(value = "update")
	public String mod(@ModelAttribute boardVO boardvo) throws Exception {
		
		System.out.println(1+boardvo.getNumbero()+"넘버안넘어왔나?");	
		ifboards.modOne(boardvo);		
		return "redirect:complaint";
	
	}
	
	
}
