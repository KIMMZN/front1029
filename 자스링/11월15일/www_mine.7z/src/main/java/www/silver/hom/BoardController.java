package www.silver.hom;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import www.silver.service.IF_BoardService;
import www.silver.util.FileDataUtil;
import www.silver.vo.BoardVO;
import www.silver.vo.PageVO;

@Controller
public class BoardController {
	
	@Inject
	IF_BoardService boardservice;
	
	@Inject
	FileDataUtil filedatautil;
	
	
	@GetMapping(value = "board")
	public String board(Model model,
			@ModelAttribute PageVO pagevo) throws Exception {//vo 파라미터로 받는다.
		
		if(pagevo.getPage()==null) {
			pagevo.setPage(1);
		}
		
		//3가지 정보만 있으면 페이지 계산이 가능
		//1현재 페이지,, 2, 페이지당 게시물 수   3. 전체페이지수
		//pagevo.setTotalCount(151);
		pagevo.setTotalCount(boardservice.totalCountBoard());
		
		//확인용
		//System.out.println(pagevo.getStartNo() + "시작 글번호");
		//System.out.println(pagevo.getEndNo() + "끝 글번호");
		//System.out.println(pagevo.getStartPage() + "그룹 시작번호");
		//System.out.println(pagevo.getEndPage() + "그룹 끝번호");
		
		//cotroller > service > dao > mapper
		//서비스 layer에 전체글 서비스를 요청하고 결과를 리턴
		List<BoardVO> list = boardservice.boardList(pagevo);
		//디버그 테스트
		System.out.println(list.size() +"건 가져옴");
		// 리턴받은 list변수의 값을 모델 객체로 뷰에게 전송하는 코드
		                    //변수명, 값
		model.addAttribute("list", list);
		// 뷰를 지정
		
		return "board/bbs"; //���������� ���ڿ��� ���ϸ����� �ν��ϰٴ�. �����ϴ� ������ home.jsp (�����ø�)
	}
	
	//bwr
	@GetMapping(value = "bwr")
	public String bwr() throws Exception {//vo 파라미터로 받는다.
		
		
		
		return "board/bbswr"; //���������� ���ڿ��� ���ϸ����� �ν��ϰٴ�. �����ϴ� ������ home.jsp (�����ø�)
	}
	
	@GetMapping(value = "del") //글삭제
	public String del(@RequestParam("delno") String delno) throws Exception {
			
		boardservice.deleteBoard(delno);
		//boardservice.deleteBoard(delno);
		return "redirect:board";
	}
	@GetMapping(value = "mod") //글수정
	public String mod(@RequestParam("modno") String modno, Model model) throws Exception {
		
		
		BoardVO bvo = boardservice.modBoard(modno);
		//System.out.println(bvo.getTitle());
		//sysout은 서버 입장에서는 부하 걸리는 작업이다.
		// 그래서 테스트 하면 삭제 하거나 주석을 해야한다.
		// 실제로sysout은 잘 사용하지 않는다.
		// 테스트 하기 위해서는  junit test라는 도구를 사용한다.
		// 또 기록을 남기기 위해서는 로그라는 기능을 사용한다.
		// 로그는 홈 컨트롤러에 가면 볼 수 있다.
		model.addAttribute("boardvo", bvo);
		return "board/bbsfom";
	}
	
	
	@PostMapping(value="mod") 
	public String modsavae(@ModelAttribute BoardVO boardvo)throws Exception {
		
		
		boardservice.modBoard(boardvo);
		//System.out.println(bvo.getTitle());
		return "redirect:board";
	}
	
	@PostMapping(value = "bwrdo") //파일업로드 추가
	public String bwrdo(@ModelAttribute BoardVO boardvo,
			MultipartFile[] file) throws Exception {//vo 파라미터로 받는다.
		//업로드 되는지 확인 하는 중간 코드
		//System.out.println(file.length);
		//for(int i=0; i<file.length; i++) {
		//	System.out.println(file[i].getOriginalFilename());
		//}
		
		String[] newFileName=filedatautil.fileUpload(file);
		//System.out.println(newFileName);
		boardvo.setFilename(newFileName);
		
		
		 
		
		
		
		//System.out.println(boardvo.toString());
		//서비스단에게 vo 객체에 저장된 데이터를 보내는 것.
		boardservice.addBoard(boardvo);
		
		return "redirect:board"; //���������� ���ڿ��� ���ϸ����� �ν��ϰٴ�. �����ϴ� ������ home.jsp (�����ø�)
	}
	
	@GetMapping(value = "view")
	public String boardView(@RequestParam("no") String no, Model model)throws Exception {
		
		BoardVO boardvo = boardservice.getBoard(no);
		//attach
		//view에게 전송할 값들, 게시글과 첨부파일 리스ㅡ
		List<String> attachList = boardservice.getAttach(no);
		model.addAttribute("boardvo", boardvo);
		model.addAttribute("attachList", attachList);
		return "board/dview";
	}
	
	
	
	
	

}
