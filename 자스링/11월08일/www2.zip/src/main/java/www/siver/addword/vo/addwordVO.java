package www.siver.addword.vo;

public class addwordVO {
	
	String Eword = "null";
	String Kword = "null";
	
	
	
	
	@Override
	public String toString() {
		return "addwordVO [Eword=" + Eword + ", Kword=" + Kword + "]";
	}
	public String getEword() {
		return Eword;
	}
	public void setEword(String eword) {
		Eword = eword;
	}
	public String getKword() {
		return Kword;
	}
	public void setKword(String kword) {
		Kword = kword;
	}
	
	
	

}
