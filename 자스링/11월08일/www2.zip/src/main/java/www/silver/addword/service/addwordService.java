package www.silver.addword.service;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import www.silver.addword.dao.IF_addwordDao;
import www.siver.addword.vo.addwordVO;

@Service
public class addwordService implements IF_addwordService {
	
	@Inject
	IF_addwordDao insertworddao;
	
	
	@Override
	public void addword(addwordVO addwordvo) throws Exception {
		// TODO Auto-generated method stub
		
		System.out.println("add워드 앤 서비스1");
		insertworddao.addWordOne(addwordvo);
		System.out.println("add워드 앤 서비스");
		
		
		
	}
	
	

}
