package www.silver.hom;

import java.util.Arrays;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

//@Controller
public class WordController1 {
	
	@RequestMapping(value ="/word", method = RequestMethod.GET)
	public String home1() {
		///@RequestParam("word") String w, Model m
		
		return "word/NewFile";
	};
	
	@RequestMapping(value ="/word1", method = RequestMethod.GET)
	public String home2(@RequestParam("word") String aa, Model m) {
		String[] wordlist = {
			    "불", "엘 프리모", "로사", "대릴", "재키", "프랭크", "비비", "애쉬", "행크", "버스터", "메그", "드라코",
			    "스튜", "에드거", "샘", "모티스", "버즈", "팽", "미코", "멜로디", "릴리", "크로우", "레온", "코델리우스", "켄지",
			    "포코", "거스", "팸", "베리", "맥스", "바이런", "러프스", "그레이", "더그", "키트", "제시", "페니", "보", "엠즈",
			    "그리프", "게일", "진", "미스터 P", "스퀴크", "루", "오티스", "윌로우", "척", "찰리", "샌디", "앰버", "쉘리",
			    "니타", "콜트", "8비트", "리코", "칼", "콜레트", "롤라", "펄", "타라", "이브", "R-T", "클랜시", "모", "스파이크",
			    "서지", "체스터", "브록", "파이퍼", "비", "나니", "보니", "벨", "맨디", "메이지", "안젤로", "자넷", "발리",
			    "다이너마이크", "틱", "그롬", "래리 & 로리", "스프라우트"
			};

		boolean flag = false;
		for(int i=0; i<wordlist.length; i++) {
			if(aa.equals(wordlist[i])) {
				flag = true;
				break;
				
			}
		}
		
		
		//변수명 영어로 써야 에러 안난다.
		m.addAttribute("searchWord", aa);
		m.addAttribute("found", flag);
	
		
		return "word/NewFile1";
		
		

	}
	
	
	
	
}
