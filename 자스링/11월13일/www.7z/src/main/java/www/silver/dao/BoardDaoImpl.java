package www.silver.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import www.silver.vo.BoardVO;
import www.silver.vo.PageVO;

@Repository
public class BoardDaoImpl implements IF_BoardDao {
	
	@Inject
	SqlSession sqlsession;
	final String mapperquery="www.silver.dao.IF_BoardDao";	
	//원래www.silver.dao.IF_BoardDao.inin	
	@Override
	public void insertBoard(BoardVO boardvo) throws Exception {
		// TODO Auto-generated method stub
		
		//sqlsession을 통해서 mapper와 매핑해야 하기에 정보를 넘겨준다.
		sqlsession.insert(mapperquery+".inin", boardvo);
	}
	
	@Override
	public List<BoardVO> selectAll(PageVO pagevo) throws Exception {
		// TODO Auto-generated method stub
		
		//System.out.println();
		
		return sqlsession.selectList(mapperquery+".selectall", pagevo);
	}

	@Override
	public void deleteBoard(String delno) throws Exception {
		// TODO Auto-generated method stub
		sqlsession.delete(mapperquery+".delone", delno);
		
	}

	@Override
	public BoardVO selectOne(String title) throws Exception {
		// TODO Auto-generated method stub
		return sqlsession.selectOne(mapperquery+".selectTitle", title);
	}

	@Override
	public void updateBoard(BoardVO boardvo) throws Exception {
		// TODO Auto-generated method stub
		if(boardvo != null) {
			if(boardvo.getViewmemeber() == null) {
				boardvo.setViewmemeber("비공개");
			}else {
				boardvo.setViewmemeber("공개");
			}		
		}			
		sqlsession.update(mapperquery+".update", boardvo);
	}

	@Override
	public int cntBoard() throws Exception {
		// TODO Auto-generated method stub
		
		return sqlsession.selectOne(mapperquery+".allcnt");
	}

}
