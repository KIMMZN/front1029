package www.silver.hom;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import www.silver.service.IF_boardservice;
import www.silver.util.FileDataUtil;
import www.silver.vo.Pagevo;
import www.silver.vo.boardVO;

@Controller
public class BoardController {

	@Inject
	IF_boardservice ifboards;
	
	@Inject
	FileDataUtil filedatautil;
	
	@GetMapping(value="complaint")
	public String announce(Model model, @ModelAttribute Pagevo pagevo) throws Exception {
		//여기가 게시판 뷰
		//클라이언트가 게시판보기를 요청
		//ifboards.listall();
		
		//model.addAttribute = ifboards.listall();
		//complaint게시판에 게시글 뿌려주기
		
		//pagevo.setTotalCount(i);
		if(pagevo.getPage() == null) {
			pagevo.setPage(1);
		}
		
		//페이징 카운트
				pagevo.setTotalCount(ifboards.totalCountBoard());
		
		List<boardVO> list = ifboards.listall(pagevo);				
		
		
		//
		System.out.println(pagevo.getStartNo() +"시작 글번호");
		System.out.println(pagevo.getEndNo() +"마지막 글번호");
		System.out.println(pagevo.getStartPage() +"그룹 시작번호");
		System.out.println(pagevo.getEndPage() +"그룹 끝 번호");
		System.out.println("List 데이터: " + list);
		
		
		System.out.println(list.size() +"건 가져옴");		
		model.addAttribute("list",list);		
		//
		//페이징
		// 3가지 정보만 있으면 페이지 계산이 가능
		// 1현재 페이지,, 2.페이지당 게시물수 3. 전체페이지
		
		
		
		return "/board/complaint";
	}
	
	@GetMapping(value="bwr")
	public String bwr() {
		
		
		
		
		return "/board/complaintWr";
	}
	
	@PostMapping(value="bwrite")
	public String bwrite(@ModelAttribute boardVO boardvo,
			MultipartFile[] file) throws Exception {
		//System.out.println(boardvo.toString());
				//업로드 되는지 확인 하는 중간 코드
			/*	System.out.println(file.length);
				for(int i=0; i<file.length; i++) {
					System.out.println(file[i].getOriginalFilename());
				}
		     */
		
		//filedatauitl
		//file업로드 한 뒤 stringp[]에 이름추가
		String[] newFileName = filedatautil.fileUpload(file);
		
		//
		boardvo.setFilename(newFileName);
		//boardvo.setFilename(newFileName);
				
		
		
		ifboards.writeOne(boardvo);
		System.out.println(boardvo.toString());
		
		return "redirect:complaint";
		
		
	}
	
	@GetMapping(value = "delone")
	public String delone(@RequestParam int delno) throws Exception {
		
		
		ifboards.delOne(delno);
		//
		//System.out.println(delno+"  넘긴 글번호");
		
		return "redirect:complaint";
	}
	
	@GetMapping(value = "update")
	public String update(@RequestParam int delno, Model model) throws Exception {
		//pk num을 param으로 넘기고
		//모델 객체 활용  뷰로 리턴
		
		boardVO baordvo = ifboards.modOne(delno);
		
		model.addAttribute(baordvo);
		
		
		System.out.println(delno+"  넘긴 글번호");
		
		return "board/complaintUpdate";
	}
	
	@PostMapping(value = "update")
	public String mod(@ModelAttribute boardVO boardvo) throws Exception {
		
		System.out.println(1+boardvo.getNumbero()+"넘버안넘어왔나?");	
		ifboards.modOne(boardvo);		
		return "redirect:complaint";
	
	}
	
	@GetMapping(value="dview")
	public String dview(@RequestParam int delno, Model model) throws Exception {
		
		System.out.println(delno+"   delno");
		//number를 파라미터로 넘기고, boradvo 객체를 통해 데이터를 리턴 받으면 됨
		
		
		boardVO boardvo = ifboards.modOne(delno);
		
		model.addAttribute(boardvo);
		 //modOne(int delno)
		
		return "board/dview";
	}
	
	
	
	
	
	
}
