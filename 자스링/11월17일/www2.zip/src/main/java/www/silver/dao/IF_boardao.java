package www.silver.dao;

import java.util.List;

import www.silver.vo.Pagevo;
import www.silver.vo.boardVO;

public interface IF_boardao {
	
	public void wirteOne(boardVO boardvo)throws Exception;
	//게시판글보기요청, 페이징 추가
	public List<boardVO> listall(Pagevo pagevo) throws Exception;
	
	//delone
	public void deleteOne(int delno)throws Exception;
	
	//select update view
	public boardVO selectOne(int delno)throws Exception;
	
	//글 수정 요청
	public void updateOne(boardVO boardvo)throws Exception;
	
	//페이지 위한토탈카운트
	public int cntBoard()throws Exception;
	

}
