package www.silver.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import www.silver.dao.IF_boardao;
import www.silver.vo.Pagevo;
import www.silver.vo.boardVO;

@Service
public class boardserviceImpl implements IF_boardservice {

	@Inject
	IF_boardao boardao;
	
	@Override
	public void writeOne(boardVO boardvo) throws Exception {
		// TODO Auto-generated method stub
		
		if(boardvo.getViewone() == null) {
			
			boardvo.setViewone("공개");
		}else {
			boardvo.setViewone("비공개");
		}
		
		boardao.wirteOne(boardvo);
		
		
	}

	@Override
	public List<boardVO> listall(Pagevo pagevo) throws Exception {
		// TODO Auto-generated method stub
		List<boardVO> list = boardao.listall(pagevo);
		//날짜 sub스트링으로 필요한부분만 저장.
		for(boardVO b : list) {
			String date = b.getIndate();
			b.setIndate(date.substring(0,10));
			
		}
		return list;
	}
	
	

	@Override
	public void delOne(int delno) throws Exception {
		// TODO Auto-generated method stub
		//boardao
		boardao.deleteOne(delno);
		
	}

	@Override //글수정페이지클릭시
	public boardVO modOne(int delno) throws Exception {
		// TODO Auto-generated method stub
		
		 
		return boardao.selectOne(delno);
	}

	@Override //글수정요청
	public void modOne(boardVO boardvo) throws Exception {
		// TODO Auto-generated method stub
		
		if(boardvo.getViewone() == null) {		
			boardvo.setViewone("공개");
		}else {
			boardvo.setViewone("비공개");
		}
		
		boardao.updateOne(boardvo);
	}

	@Override
	public int totalCountBoard() throws Exception {
		// TODO Auto-generated method stub
		
		return boardao.cntBoard();
	}


}
