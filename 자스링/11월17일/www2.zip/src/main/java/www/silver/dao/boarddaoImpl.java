package www.silver.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import www.silver.vo.Pagevo;
import www.silver.vo.boardVO;

@Repository
public class boarddaoImpl implements IF_boardao {
	
	@Inject
	SqlSession sqlsession;
	
	String query = "www.silver.dao.IF_boardao";

	@Override
	public void wirteOne(boardVO boardvo) throws Exception {
		// TODO Auto-generated method stub
		
		sqlsession.insert(query+".addWriteOne", boardvo);
		

		
	}

	@Override
	public List<boardVO> listall(Pagevo pagevo) throws Exception {
		// TODO Auto-generated method stub
		
		//게시글 전체보기에 페이징을 위한 pagevo 추가
		return sqlsession.selectList(query+".listall",pagevo);
	}

	@Override
	public void deleteOne(int delno) throws Exception {
		// TODO Auto-generated method stub
		//deleteOne
		
		sqlsession.delete(query+".deleteOne", delno);
		
	}

	@Override
	public boardVO selectOne(int delno) throws Exception {
		// TODO Auto-generated method stub
		//sqlsession.selectList(query+".selectOne", delno);
		//sqlsession.selectOne(query+".selectOne", delno);
		//sqlsession.select(query+".selectOne", delno);
		return sqlsession.selectOne(query+".selectOne", delno);
	}

	@Override
	public void updateOne(boardVO boardvo) throws Exception {
		// TODO Auto-generated method stub
		sqlsession.update(query+".updateOne", boardvo);
		
		//sqlsession.selectOne(query+".selectOne", delno);
		
	}

	@Override
	public int cntBoard() throws Exception {
		// TODO Auto-generated method stub
		
		
		return sqlsession.selectOne(query+".allcnt");
	}

	
}
