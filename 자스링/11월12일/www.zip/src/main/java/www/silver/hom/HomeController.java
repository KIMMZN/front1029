package www.silver.hom;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/** aaa
 * Handles requests for the application home page.
 */
//@RestController - 비동기 stirng int 등등
@Controller //controller�� ������ ��Ʈ�ѷ���� �����ϴ°� // ��Ʈ�ѷ� Ŭ���� ����
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	//Ŭ���̾�Ʈ�� ��û�ϴ°� value���̴�(request mapping)
	//hom/ ���� /~~ �ּҰ� value"/"�̴�
	//hom/ �� context path(request)�̴�.
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		//return home // home�� �����ϴ� ���ϸ��̴�
		return "home"; //���������� ���ڿ��� ���ϸ����� �ν��ϰٴ�. �����ϴ� ������ home.jsp (�����ø�)
	}
	
	//https://bubblecastle.tistory.com/9
	@RequestMapping(value = "/timeline", method = RequestMethod.GET)
	public String timeline() {
		return "timeline";
	}
	
	@RequestMapping(value = "/viewMessage",  method = RequestMethod.GET)
	public String viewMessage(@RequestParam("time") String t,
			@RequestParam("name") String n, Model m) {
		//spring은 객체를 자동으로 생성해줌 //Model등.
		
		//ctrl space 단축키
		// m 모델 뷰에게 값 넘겨줄대 사용되는 객체
		//디버깅 - 확인용
		m.addAttribute("변수명","값");
		m.addAttribute("time", t);
		m.addAttribute("name",n);
		m.addAttribute("age", 100);
		//m.addAllAttribute("변수명", "값");
		System.out.println(t+"/"+n);
		return "viewMsg";
	}

	@RequestMapping(value = "/viewMessage",  method = RequestMethod.POST)
	public String viewMessage1(@RequestParam("time") String t,
			@RequestParam("name") String n, Model m) {
		//spring은 객체를 자동으로 생성해줌 //Model등.
		
		//ctrl space 단축키
		// m 모델 뷰에게 값 넘겨줄대 사용되는 객체
		//디버깅 - 확인용
		m.addAttribute("변수명","값");
		m.addAttribute("time", t);
		m.addAttribute("name",n);
		m.addAttribute("age", 100);
		//m.addAllAttribute("변수명", "값");
		System.out.println(t+"/"+n);
		return "viewMsg";
	}
	
}
