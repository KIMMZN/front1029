package www.silver.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import www.silver.vo.BoardVO;

@Repository
public class BoardDaoImpl implements IF_BoardDao {
	
	@Inject
	SqlSession sqlsession;
	final String mapperquery="www.silver.dao.IF_BoardDao";	
	//원래www.silver.dao.IF_BoardDao.inin	
	@Override
	public void insertBoard(BoardVO boardvo) throws Exception {
		// TODO Auto-generated method stub
		
		//sqlsession을 통해서 mapper와 매핑해야 하기에 정보를 넘겨준다.
		sqlsession.insert(mapperquery+".inin", boardvo);
	}
	
	@Override
	public List<BoardVO> selectAll() throws Exception {
		// TODO Auto-generated method stub
		
		//System.out.println();
		
		return sqlsession.selectList(mapperquery+".selectall");
	}

	@Override
	public void deleteBoard(String delno) throws Exception {
		// TODO Auto-generated method stub
		sqlsession.delete(mapperquery+".delone", delno);
		
	}

}
