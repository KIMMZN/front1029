package www.silver.hom;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import www.silver.service.IF_boardservice;
import www.silver.vo.boardVO;

@Controller
public class BoardController {

	@Inject
	IF_boardservice ifboards;
	
	@GetMapping(value="complaint")
	public String announce(Model model) throws Exception {
		//여기가 게시판 뷰
		//클라이언트가 게시판보기를 요청
		//ifboards.listall();
		
		//model.addAttribute = ifboards.listall();
		
		List<boardVO> list = ifboards.listall();
		
		System.out.println(list.size() +"건 가져옴");
		
		model.addAttribute("list",list);
		
				
		return "/board/complaint";
	}
	
	@GetMapping(value="bwr")
	public String bwr() {
		
		
		
		
		return "/board/complaintWr";
	}
	
	@PostMapping(value="bwrite")
	public String bwrite(@ModelAttribute boardVO boardvo) throws Exception {
		
		
		ifboards.writeOne(boardvo);
		System.out.println(boardvo.toString());
		
		return "redirect:complaint";
	}
	
	
	
	
	
	
}
