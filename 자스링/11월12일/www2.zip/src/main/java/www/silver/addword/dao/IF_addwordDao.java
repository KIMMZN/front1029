package www.silver.addword.dao;

import www.siver.addword.vo.addwordVO;

public interface IF_addwordDao {
	
	public void addWordOne(addwordVO addwordvo) throws Exception;

}
