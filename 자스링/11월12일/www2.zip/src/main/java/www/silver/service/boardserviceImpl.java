package www.silver.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import www.silver.dao.IF_boardao;
import www.silver.vo.boardVO;

@Service
public class boardserviceImpl implements IF_boardservice {

	@Inject
	IF_boardao boardao;
	
	@Override
	public void writeOne(boardVO boardvo) throws Exception {
		// TODO Auto-generated method stub
		
		if(boardvo.getViewone() == null) {
			
			boardvo.setViewone("비공개");
		}else {
			boardvo.setViewone("공개");
		}
		
		boardao.wirteOne(boardvo);
		
		
	}

	@Override
	public List<boardVO> listall() throws Exception {
		// TODO Auto-generated method stub
		
		return boardao.listall();
	}


}
