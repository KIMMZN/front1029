package www.silver.vo;

public class boardVO {
	
	int numbero;
	String type;
	String username;
	String pass;
	String title;
	String content;
	String viewone;
	String indate;
	
	
	
	
	
	
	@Override
	public String toString() {
		return "boardVO [numbero=" + numbero + ", type=" + type + ", username=" + username + ", pass=" + pass
				+ ", title=" + title + ", content=" + content + ", viewone=" + viewone + ", indate=" + indate + "]";
	}



	public String getViewone() {
		return viewone;
	}



	public void setViewone(String viewone) {
		this.viewone = viewone;
	}



	public String getIndate() {
		return indate;
	}



	public void setIndate(String indate) {
		this.indate = indate;
	}



	public int getNumbero() {
		return numbero;
	}



	public void setNumbero(int numbero) {
		this.numbero = numbero;
	}



	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	
	
	
	

}
