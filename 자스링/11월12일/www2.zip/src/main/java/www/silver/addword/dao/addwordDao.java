package www.silver.addword.dao;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import www.siver.addword.vo.addwordVO;

@Repository
public class addwordDao implements IF_addwordDao {
	

	//sqlSession이 필요합니다. // mybatis에서 제공하는 객체
	//주소가 올바르게 주입되려면 root-context.xml에서 설정이 잘 되어 있어야 한다. @
	@Inject
	SqlSession SqlSession;
	
	private String mapperQuery= "www.silver.addword.dao.IF_addwordDao";

	@Override
	public void addWordOne(addwordVO addwordvo) throws Exception {
		// TODO Auto-generated method stub
		
		SqlSession.insert(mapperQuery+".addWordOne",addwordvo);
		
	}

}
