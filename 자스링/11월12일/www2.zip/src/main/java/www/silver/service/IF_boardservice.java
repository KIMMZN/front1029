package www.silver.service;

import java.util.List;

import www.silver.vo.boardVO;

public interface IF_boardservice {
	
	public void writeOne(boardVO boardvo) throws Exception;
	public List<boardVO> listall() throws Exception;

}
