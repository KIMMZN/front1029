package www.silver.dao;

import java.util.List;

import www.silver.vo.boardVO;

public interface IF_boardao {
	
	public void wirteOne(boardVO boardvo)throws Exception;
	//게시판글보기요청
	public List<boardVO> listall() throws Exception;

}
