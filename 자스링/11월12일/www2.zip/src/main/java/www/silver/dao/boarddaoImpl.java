package www.silver.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import www.silver.vo.boardVO;

@Repository
public class boarddaoImpl implements IF_boardao {
	
	@Inject
	SqlSession sqlsession;
	
	String query = "www.silver.dao.IF_boardao";

	@Override
	public void wirteOne(boardVO boardvo) throws Exception {
		// TODO Auto-generated method stub
		
		sqlsession.insert(query+".addWriteOne", boardvo);
		

		
	}

	@Override
	public List<boardVO> listall() throws Exception {
		// TODO Auto-generated method stub
		
		
		return sqlsession.selectList(query+".listall");
	}

	
}
