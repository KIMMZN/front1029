package www.silver.addword.service;

import www.siver.addword.vo.addwordVO;

public interface IF_addwordService {
	

	public void addword(addwordVO addwordvo) throws Exception;

}
