package www.silver.service;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import www.silver.dao.IF_BoardDao;
import www.silver.vo.BoardVO;

@Service
public class BoardServicempl implements IF_BoardService  {
	
	
	@Inject
	IF_BoardDao boarddao;
	

	@Override
	public void addBoard(BoardVO boardvo) throws Exception {
		// TODO Auto-generated method stub
		
		if(boardvo != null) {
			if(boardvo.getViewmemeber() == null) {
				boardvo.setViewmemeber("비공개");
			}else {
				boardvo.setViewmemeber("공개");
			}		
		}		
		boarddao.insertBoard(boardvo);
		
	}

}
